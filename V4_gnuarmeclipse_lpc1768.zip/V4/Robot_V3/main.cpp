/***********************************************************************
**  ██████╗ ███████╗██╗███████╗██╗    ██╗ █████╗ ██████╗ ███╗   ███╗  **
**  ██╔══██╗██╔════╝██║██╔════╝██║    ██║██╔══██╗██╔══██╗████╗ ████║  **
**  ██████╔╝███████╗██║███████╗██║ █╗ ██║███████║██████╔╝██╔████╔██║  **
**  ██╔═══╝ ╚════██║██║╚════██║██║███╗██║██╔══██║██╔══██╗██║╚██╔╝██║  **
**  ██║     ███████║██║███████║╚███╔███╔╝██║  ██║██║  ██║██║ ╚═╝ ██║  **
**  ╚═╝     ╚══════╝╚═╝╚══════╝ ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  **
************************************************************************
** Copyright 2017 University of York - See notice at end of file      **
***********************************************************************/

/// PsiSwarm C++ Blank Example Code - Version 0.9 - June 2017
/// James Hilder, Alan Millard, Alexander Horsfield, Homero Elizondo, Jon Timmis

/// Include main.h - this includes psiswarm.h all the other necessary core files
#include "main.h"
#include "cstdlib"

Psiswarm psi;
string command;
char * program_name = "Blank";
char * author_name  = "YRL";
char * version_name = "0.90";

///Place user code here that should be run after initialisation but before the main loop
void user_code_setup()
{
    wait(0.8); // The display is still updating from init so wait a short while
    display.clear_display();
    display.set_position(0,0);
    animations.set_colour(1);
    display.write_string(" [  V4  ]");   
}

///User code loop:  This is where user code should go; it is run as an infinite loop
void user_code_loop()
{
    // Replace this code with your main loop
    //MOTORS
    if (command.find("forward") != string::npos){//Koko
        char buffc[50]="";// holds the char for the numbers after the comands
        int countc = 7;// counter for the and of the commnd
        int countb = 0;//counter for the number
        while(command[countc]&&countb<8){// takes the numbers after the command
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        float vall= atof(buffc);//converts the string of numbers to float
        command="";// resets the command to null
        if(vall>=-1&&vall<=1){//evaluates the values to be in range
            motors.forward(vall);//execute the function
        }else{
            printf("Invalid motor.forward value!(%f)",vall);// print worning mesage
            wait(0.001);
            printf("\n");
        }
    }
    
    if (command.find("backward") != string::npos){//Koko
        char buffc[50]="";
        int countc = 8;
        int countb = 0;
        while(command[countc]&&countb<8){
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        float vall= atof(buffc);
        command="";
        if(vall>=-1&&vall<=1){
            motors.backward(vall);
        }else{
            printf("Invalid motor.backward value!(%f)",vall);
            wait(0.001);
            printf("\n");
        }
    }
    
    if(command=="brake"){//Koko
    motors.brake();
    command="";
    }
    
    if(command=="stop"){//
    motors.stop();
    command="";
    }
    
    if(command=="brakeleft"){//
    motors.brake_left_motor();
    command="";
    }
    
    if(command=="brakeright"){//
    motors.brake_right_motor();
    command="";
    }
    
    if (command.find("leftmotor") != string::npos){//Rob
        char buffc[50]="";
        int countc = 9;
        int countb = 0;
        while(command[countc]&&countb<8){// takes the numbers after the command (dont change the 8 )
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        float vall= atof(buffc);
        command="";
        if(vall>=-1&&vall<=1){
            motors.set_left_motor_speed(vall);
        }else{
            printf("Invalid motor.leftmotor value!(%f)",vall);
            wait(0.001);
            printf("\n");
        }
        }
        
            if (command.find("rightmotor") != string::npos){//jb
        char buffc[50]="";
        int countc = 10;
        int countb = 0;
        while(command[countc]&&countb<8){// takes the numbers after the command (dont change the 8 )
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        float vall= atof(buffc);
        command="";
        if(vall>=-1&&vall<=1){
            motors.set_right_motor_speed(vall);
        }else{
            printf("Invalid motor.rightmotor value!(%f)",vall);
            wait(0.001);
            printf("\n");
        }
        }
        
            ///Animation
            
    if(command=="vibrate"){//koko
    animations.vibrate();
    wait(1);
    command="";
    }
    
    if(command=="ledrun1"){//
    animations.led_run1();
    wait(1);
    command="";
    }
    
    if (command.find("setcolour") != string::npos){//jb
        char buffc;
        int countc = 9;
        int countb = 0;
        while(command[countc]&&countb<1){
            buffc = command[countc];
            countc++;
            countb++;
            }
        command="";
        if(buffc=='1'||buffc=='2'||buffc=='3'){
            animations.set_colour(buffc);
        }else{
            printf("Invalid LED input");
            wait(0.001);
            printf("\n");
        }
        }
        
            ///Colour
            
            if (command.find("startcrticker") != string::npos){//Koko
        char buffc[50]="";
        int countc = 13;
        int countb = 0;
        while(command[countc]&&countb<6){
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        int vall= atof(buffc);
        command="";
        if(vall>=1&&vall<=100000){
            colour.start_colour_ticker(vall);
        }else{
            printf("Invalid colour ticker value!(%i)",vall);
            wait(0.001);
            printf("\n");
        }
    }
    
        if(command=="stopcolourticker"){//
    colour.stop_colour_ticker();
    command="";
    }
    
    if(command=="detectcolouronce"){//
    colour.detect_colour_once();
    command="";
    }
    
    if(command=="getcolourstring"){//
    pc.printf("%s",colour.get_colour_string(colour.get_detected_colour())); 
    wait(0.10);
    printf("\n");
    command="";
    }
    
    if(command=="readbasecolour"){//koko
    int RGB [4];
    colour.read_base_colour_sensor_values(RGB);
    pc.printf("%i",RGB[1]); 
    pc.printf("%i",RGB[2]);
    pc.printf("%i",RGB[3]);
    wait(0.10);
    printf("\n");
    command="";
    }
    
        //DISPLAY
            
    if(command=="cleardisplay"){//
    display.clear_display(); 
    command="";
    }
    
    if(command=="home"){//
    display.home(); 
    command="";
    }
    
    //limited to 10 char becouse of the buffer size
    if (command.find("writestring") != string::npos){//Koko
        char buffc[11]="";
        int countc = 11;
        int countb = 0;
        while(command[countc]&&countb<10){
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        command="";
            display.write_string(buffc);
    }
            //LEDS
            
        if (command.find("setleds") != string::npos){//Koko
            char greenbin[3]="";
            char redbin[3]="";
        int countcgreen = 7;
        int countcred = 10;
        int countb = 0;
        while(command[countcgreen]&&countb<3){
            greenbin[countb] = command[countcgreen];
            countcgreen++;
            countb++;
            }
        countb = 0;
        while(command[countcred]&&countb<3){
            redbin[countb] = command[countcred];
            countcred++;
            countb++;
            }
        command="";
        int vallgreen= atof(greenbin);
        int vallred= atof(redbin);
        if(vallgreen>=0 && vallgreen<256 && vallred>=0 && vallred<256){
             led.set_leds(vallgreen,vallred);
        }else{
            pc.printf("wrong set leds valles.\n");
        }
    }
    
    if (command.find("setgreenleds") != string::npos){//Koko
        char bin[3]="";
        int countc = 12;
        int countb = 0;
        while(command[countc]&&countb<3){
            bin[countb] = command[countc];
            countc++;
            countb++;
            }
        command="";
        int vall= atof(bin);
        if(vall>=0 && vall<256){
             led.set_green_leds(vall);
        }else{
            pc.printf("wrong set green leds valles.\n");
        }
        }
    
    if (command.find("setredleds") != string::npos){//Koko
        char bin[3]="";
        int countc = 10;
        int countb = 0;
        while(command[countc]&&countb<3){
            bin[countb] = command[countc];
            countc++;
            countb++;
            }
        command="";
        int vall= atof(bin);
        if(vall>=0 && vall<256){
             led.set_red_leds(vall);
        }else{
            pc.printf("wrong set red leds valles.\n");
    }
    }
    if (command.find("setled") != string::npos){//Koko
            char ledbin[1]="";
            char colourbin[1]="";
        ledbin[0]=command[6];
        colourbin[0]=command[7];
        command="";
        int lednumber= atof(ledbin);
        int colour= atof(colourbin);
        if(lednumber>=0 && lednumber<8 && colour>=0 && colour<4){ 
           led.set_led(lednumber,colour);
        }else{
            pc.printf("wrong set led valles.\n");
            
    }
    }
    if (command.find("setbaseled") != string::npos){//Koko
            char statebin[1]="";
        statebin[0]=command[10];
        command="";
        int state= atof(statebin);
        if(state==0 || state==1){ 
           led.set_base_led(state);
           
        }else{
            pc.printf("Wrong set base led value\n");
            
    }
    }
    
    if (command.find("blinkleds") != string::npos){//Koko
        char buffc[50]="";
        int countc = 9;
        int countb = 0;
        while(command[countc]&&countb<8){
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        float vall= atof(buffc);
        command="";
        if(vall>=0&&vall<=1000){
            led.blink_leds(vall);
        }else{
            printf("Invalid led blink time: %f",vall);
            wait(0.001);
            printf("\n");
        }
        }
        
        if (command.find("setcenterled") != string::npos){//Koko
            char statebin[1]="";
        statebin[0]=command[12];
        command="";
        int state= atof(statebin);
        if(state>=0 && state<=3){ 
           led.set_center_led(state);
           
        }else{
            pc.printf("Wrong set center led value\n");
            
    }
    }
    if (command.find("setCledB") != string::npos){//Koko
        char buffc[50]="";
        int countc = 8;
        int countb = 0;
        while(command[countc]&&countb<8){
            buffc[countb] = command[countc];
            countc++;
            countb++;
            }
        float vall= atof(buffc);
        command="";
        if(vall>=-1&&vall<=1){
            led.set_center_led_brightness(vall);
        }else{
            printf("Invalid Central led Brithess(%f)",vall);
            wait(0.001);
            printf("\n");
        }
    }
    if (command.find("getledstate") != string::npos){//koko
            printf("%i",led.get_led_states());// actual value
            wait(0.001);
            printf("\n");
            command="";
        }
    
            ////SOUND
                // coudnt make sound work
            ////SENSORS
        
        
            if (command.find("getbattvolt") != string::npos){//
            wait(0.01);
           // printf("- DC Voltage     : %1.3f V\n",sensors.get_dc_voltage());// test message
            printf("%f",sensors.get_dc_voltage());// actual value
            wait(0.001);
            printf("\n");
            command="";
        }
        
        // JB
              if (command.find("getcurr") != string::npos){
                  wait(0.01);
           // printf("- DC Current     : %1.3f V\n",sensors.get_current());// test message
            printf("%f",sensors.get_current());// actual value
            wait(0.001);
            printf("\n");
            command="";
        }
        
                // JB
              if (command.find("gettemp") != string::npos){
                  wait(0.1);
           // printf("- DC Temperature     : %1.3f V\n",sensors.get_temperature());// test message
            printf("%f",sensors.get_temperature());// actual value
            wait(0.001);
            printf("\n");
            command="";
        }
        
                // JB
              if (command.find("getdcvolt") != string::npos){
                  wait(0.1);
            //printf("- DC Battery Voltage     : %1.3f V\n",sensors.get_battery_voltage());// test message
            wait(0.001);
            printf("%f",sensors.get_battery_voltage());// actual value
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("enablesonicticker") != string::npos){//
            wait(0.01);
            //printf("tested");// test message
            sensors.enable_ultrasonic_ticker();
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("disablesonicticker") != string::npos){//
            wait(0.01);
            //printf("tested");// test message
            sensors.disable_ultrasonic_ticker();
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("updatesonicmeasure") != string::npos){//
            wait(0.01);
           // printf("tested");// test message
            sensors.update_ultrasonic_measure();
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("storebgrawir") != string::npos){//
            wait(0.01);
            //printf("tested");// test message
            sensors.store_background_raw_ir_values();
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("storeillumrawir") != string::npos){//
            wait(0.01);
            //printf("tested");// test message
            sensors.store_illuminated_raw_ir_values();
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("storeirvalues") != string::npos){//
            wait(0.01);
           // printf("tested");// test message
            sensors.store_ir_values();
            wait(0.001);
            printf("\n");
            command="";
        }
        if (command.find("getbgrawir") != string::npos){//Koko
        wait(0.01);
            char sensorbin[1]="";
        sensorbin[0]=command[10];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.get_background_raw_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            printf("\n");
            
    }
    }
    if (command.find("getillumrawir") != string::npos){//Koko
    wait(0.01);
            char sensorbin[1]="";
        sensorbin[0]=command[13];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.get_illuminated_raw_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            printf("\n");
            
    }
    }
    if (command.find("calculatesideir") != string::npos){//Koko
    wait(0.01);
            char sensorbin[1]="";
        sensorbin[0]=command[15];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.calculate_side_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            printf("\n");
            
    }
    }
    if (command.find("readillumrawir") != string::npos){//Koko
    wait(0.01);
            char sensorbin[1]="";
        sensorbin[0]=command[14];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.read_illuminated_raw_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            printf("\n");
            
    }
    }
     if (command.find("storebgbaseir") != string::npos){//
            wait(0.1);
            sensors.store_background_base_ir_values();
            command="";
           // printf("tested");// test message
    } 
    if (command.find("storeillumbaseir") != string::npos){//
            wait(0.1);
            sensors.store_illuminated_base_ir_values();
            command="";
          //  printf("tested");// test message
    }
    if (command.find("storebaseir") != string::npos){//
            wait(0.1);
            sensors.store_base_ir_values();
            command="";
           // printf("tested");// test message
    }
    if (command.find("getbgbaseir") != string::npos){//Koko
    wait(0.1);
            char sensorbin[1]="";
        sensorbin[0]=command[11];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.get_background_base_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            pc.printf("\n");         
    }
    }
    if (command.find("getillumbaseir") != string::npos){//Koko
    wait(0.1);
            char sensorbin[1]="";
        sensorbin[0]=command[14];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.get_illuminated_base_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            printf("\n");         
    }
    }
    if (command.find("calculatebaseir") != string::npos){//Koko
    wait(0.1);
            char sensorbin[1]="";
        sensorbin[0]=command[15];
        command="";
        int sensor= atof(sensorbin);
        if(sensor>=0 && sensor<=7){ 
           pc.printf("%i",sensors.calculate_base_ir_value(sensor));
           printf("\n");
           
        }else{
            pc.printf("Sensor No invalid");
            printf("\n");         
    }
    }   
    
    
}

/// Code goes here to handle what should happen when the user switch is pressed
void handle_switch_event(char switch_state)
{
    /// Switch_state = 1 if up is pressed, 2 if down is pressed, 4 if left is pressed, 8 if right is pressed and 16 if the center button is pressed
    /// NB For maximum compatability it is recommended to minimise reliance on center button press
}

void handle_user_serial_message(char * message, char length, char interface)
{
    // This is where user code for handling a (non-system) serial message should go
    //
    // message = pointer to message char array
    // length = length of message
    // interface = 0 for PC serial connection, 1 for Bluetooth
   // printf("final input : %s\n",message);//testing perpose
    command = message;
}

/// The main routine: it is recommended to leave this function alone and add user code to the above functions
int main()
{
    psi.init();             ///psi.init() in psiswarm.cpp sets up the robot
    user_code_setup();      ///run user code setup block
    user_code_running = 1;  ///nb. user code can be paused by external commands sent from PC\BT interfaces
    while(1) {
        if(user_code_running == 1) user_code_loop();   ///run user code
        else wait_us(1000);
    }
}


/***********************************************************************
** Copyright 2017 University of York                                  **
**                                                                    **
** Licensed under the Apache License, Version 2.0 (the "License")     **
** You may not use this file except in compliance with the License.   **
** You may obtain a copy of the License at                            **
** http://www.apache.org/licenses/LICENSE-2.0   Unless required by    **
** applicable law or agreed to in writing, software distributed under **
** under the License is distributed on an "AS IS" BASIS WITHOUT       **
** WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   **
** See the License for the specific language governing permissions    **
** and limitations under the License.                                 **
***********************************************************************/