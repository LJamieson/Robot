/*
 * rosserial Temperature Sensor Example
 *
 * This tutorial demonstrates the usage of the
 * temperature function on the PsiSwarm bot
 */

#include "mbed.h"
#include "psiswarm.h"
#include "sensors.h"
#include <ros.h>
#include <std_msgs/Float32.h>

Psiswarm psi;

ros::NodeHandle  nh;

std_msgs::Float32 temp_msg;
ros::Publisher pub_temp("temperature", &temp_msg);


Timer t;


int main() {
    t.start();
    nh.initNode();
    nh.advertise(pub_temp);
    long publisher_timer =0;

    while (1) {

        if (t.read_ms() > publisher_timer) {
            // step 1: request reading from sensor
            //Wire.requestFrom(sensorAddress,2);
            char cmd = 2;

            wait_ms(50);

            float temperature;

            temp_msg.data = get_temperature();
            pub_temp.publish(&temp_msg);

            publisher_timer = t.read_ms() + 1000;
        }

        nh.spinOnce();
    }
}