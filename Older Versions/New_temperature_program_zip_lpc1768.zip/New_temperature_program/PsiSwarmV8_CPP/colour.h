/* University of York Robotics Laboratory PsiSwarm Library: Colour Sensors Header File
 *
 * Copyright 2016 University of York
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * File: colour.h
 *
 * (C) Dept. Electronics & Computer Science, University of York
 * James Hilder, Alan Millard, Alexander Horsfield, Homero Elizondo, Jon Timmis
 *
 * PsiSwarm Library Version: 0.8
 *
 * October 2016
 *
 *
 */


#ifndef COLOUR_H
#define COLOUR_H

/**
 *  The Colour class contains the functions for reading the base-mounted and top-mounted I2C colour sensors (optional).
*/
class Colour
{
public:
    /** Set the gain of the base colour sensor
    *
    * @param gain The gain value for the sensor
    */
    void set_base_colour_sensor_gain(char gain);

    /** Set the integration time constant for the base colour sensor
    *
    * @param gain The gain value for the sensor
    */
    void set_base_colour_sensor_integration_time(char int_time);

    /** Enable the base colour sensor
    */
    void enable_base_colour_sensor(void);

    /** Read the values from the base colour sensor
    *
    * @param Pointer to 3 x int array for r-g-b values
    */
    void read_base_colour_sensor_values(int * store_array);
    char IF_check_base_colour_sensor(void);

};
#endif