/* University of York Robotics Laboratory PsiSwarm Library: Eprom Functions Header File
 *
 * Copyright 2016 University of York
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * File: eprom.h
 *
 * (C) Dept. Electronics & Computer Science, University of York
 * James Hilder, Alan Millard, Alexander Horsfield, Homero Elizondo, Jon Timmis
 *
 * PsiSwarm Library Version: 0.8
 *
 * October 2016
 *
 */


#ifndef EPROM_H
#define EPROM_H

/** Eprom Class
 * Functions for accessing the 64Kb EPROM chip and reading the reserved firmware block
 *
 * Example:
 * @code
 * #include "psiswarm.h"
 *
 * int main() {
 *     init();
 *     eprom.write_eeprom_byte(0,0xDD);    //Writes byte 0xDD in EPROM address 0
 *     char c = eprom.read_eeprom_byte(0); //c will hold 0xDD
 *     //Valid address range is from 0 to 65279
 * }
 * @endcode
 */
class Eprom
{

public:

    /** Write a single byte to the EPROM
     *
     * @param address The address to store the data, range 0-65279
     * @param data The character to store
     */
    void write_eeprom_byte ( int address, char data );

    /** Read a single byte from the EPROM
     *
     * @param address The address to read from, range 0-65279
     * @return The character stored at address
     */
    char read_eeprom_byte ( int address );

    /** Read the next byte from the EPROM, to be called after read_eeprom_byte
     *
     * @return The character stored at address after the previous one read from
     */
    char read_next_eeprom_byte ( void );

    /** Read the data stored in the reserved firmware area of the EPROM
     *
     * @return 1 if a valid firmware is read, 0 otherwise
     */
    char read_firmware ( void );

};

#endif