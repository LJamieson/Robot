/* University of York Robotics Laboratory PsiSwarm Library: Colour Sensors Source File
 * 
 * Copyright 2016 University of York
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * File: colour.cpp
 *
 * (C) Dept. Electronics & Computer Science, University of York
 * James Hilder, Alan Millard, Alexander Horsfield, Homero Elizondo, Jon Timmis
 *
 * PsiSwarm Library Version: 0.8
 *
 * October 2016
 *
 */


// Base colour sensor is a TCS34725
// Top colour sensor (if fitted) is a TCS34721
#include "psiswarm.h"


void Colour::read_base_colour_sensor_values(int * store_array){
    
}

void Colour::set_base_colour_sensor_gain(char gain){
    
}

void Colour::set_base_colour_sensor_integration_time(char int_time){
    
}

void Colour::enable_base_colour_sensor(void){
    
}

char Colour::IF_check_base_colour_sensor(void){
    //Reads the device ID flag of the colour sensor [0xB2]
    //This should equal 0x44 for both TCS34721 (top) and TCS34725 (base) sensors
    //Return a 1 if successful or a 0 otherwise
    char return_value = 0;
    char data[1] = {0x00};
    char command[1] = {0xB2};
    primary_i2c.write(BASE_COLOUR_ADDRESS, command, 1, false);
    primary_i2c.read(BASE_COLOUR_ADDRESS, data, 1, false);
    if(data[0] == 0x44) return_value = 1;
    else psi.debug("Invalid response from colour sensor:%X\n",data[0]);
    return return_value;
}
